Please see in \src\main\resources  configurations for
start page URL,
CSV separator for values,
header for CSV columns,
CSV file name,
CSV file extension.