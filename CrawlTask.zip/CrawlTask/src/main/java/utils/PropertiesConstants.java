package utils;

public interface PropertiesConstants {
	String MAIN_PAGE = "main_page";
	String CSV_SEPARATOR = "csv_separator";
	String LINE_SEPARATOR = "line_separator";
	String HEADER_COLUMNS = "header_columns";
	String OUTPUT_FILE_NAME = "output_file_name";
	String OUTPUT_FILE_EXTENSION = "output_file_extension";
}
